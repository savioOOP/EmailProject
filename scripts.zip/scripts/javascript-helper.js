var isDropValid = (evt) => {
    return (evt.target.className.indexOf("droplocation") != -1);
};

var autoResizeDropLocators = () => {
    let droplocationAll = document.querySelectorAll(".droplocation");

    droplocationAll.forEach((elem) => {
        if (elem.children.length == 0) { // current drop location is empty
            elem.style.padding = "3% 0 3% 0";

            if (elem.textContent.trim() == "") {
                elem.textContent = "A VALID DROP LOCATION FOR THE SEGMENT CONTROL";
            }
        }
        else {
            elem.style.padding = "unset";

            if (elem.textContent.trim() != "") {
                let segmentComponent = Array.prototype.slice.call(elem.children);

                elem.innerHTML = "";

                elem.appendChild(segmentComponent[0]);
            }
        }
    });
};

var initializeDropLocators = () => {
    // Setting a default text placeholder onto the footer drop locator

    let dropLocationFooter = document.querySelector("ion-footer > .droplocation");

    if (dropLocationFooter) {
        if (!dropLocationFooter.children.length) {
            // Ionic Segment control is NOT yet created within. Therefore set a default text placeholder as per below
            dropLocationFooter.textContent = "ADD A SEGMENT CONTROL HERE";

            dropLocationFooter.style.color = "tomato";
        }
    }

    // Auto resizing all drop locators
    autoResizeDropLocators();
};

var openSelectOptions = (evt) => {
    let selectControl = document.querySelector("ion-select");

    selectControl.open().then(function (value) {
    });
};

var insertSVG = (svgName, icon_inner_elem) => {
    let d = [
        {
            iconName: "flag",
            iconValue: "M396 83.2c-13.8 1.7-31.1 4.2-49.6 4.2-28.8 0-55-6.8-81.5-12.2C238 69.7 210.2 64 180.8 64c-58.6 0-78.5 12.1-80.6 13.4L96 80.3V448h48V269.8c9.7-1.2 21.9-2 36.9-2 27.3 0 52.8 10 79.8 15.5 27.6 5.6 56 11.5 86.9 11.5 18.4 0 34.6-2.4 48.4-4 7.5-.9 14-1.7 20-2.7V80.2c-5 1-12.5 2.1-20 3z"
        },
        {
            iconName: "attach",
            iconValue: "M341.334 128v234.666C341.334 409.604 302.938 448 256 448c-46.937 0-85.333-38.396-85.333-85.334V117.334C170.667 87.469 194.135 64 224 64c29.864 0 53.333 23.469 53.333 53.334v245.333c0 11.729-9.605 21.333-21.334 21.333s-21.333-9.604-21.333-21.333V160h-32v202.667C202.667 392.531 226.135 416 256 416c29.865 0 53.334-23.469 53.334-53.333V117.334C309.334 70.401 270.938 32 224 32s-85.334 38.401-85.334 85.334v245.332C138.667 427.729 190.938 480 256 480c65.062 0 117.334-52.271 117.334-117.334V128h-32z"
        },
        {
            iconName: "mail",
            iconValue: "M437.332 80H74.668C51.199 80 32 99.198 32 122.667v266.666C32 412.802 51.199 432 74.668 432h362.664C460.801 432 480 412.802 480 389.333V122.667C480 99.198 460.801 80 437.332 80zM432 170.667L256 288 80 170.667V128l176 117.333L432 128v42.667z"
        },
        {
            iconName: "trash",
            iconValue: "M128 405.429C128 428.846 147.198 448 170.667 448h170.667C364.802 448 384 428.846 384 405.429V160H128v245.429zM416 96h-80l-26.785-32H202.786L176 96H96v32h320V96z"
        },
        {
            iconName: "create",
            iconValue: "M64 368v80h80l235.727-235.729-79.999-79.998L64 368zm377.602-217.602c8.531-8.531 8.531-21.334 0-29.865l-50.135-50.135c-8.531-8.531-21.334-8.531-29.865 0l-39.468 39.469 79.999 79.998 39.469-39.467z"
        },
        {
            iconName: "flash",
            iconValue: "M160 48v224h64v192l128-256h-64l64-160H160z"
        },
        {
            iconName: "ios-funnel",
            iconValue: "M48 87.2c0 5.8 2 11.4 5.6 15.7l152.2 179.8c3.6 4.3 5.6 9.9 5.6 15.7v107c0 10 5.9 18.8 14.6 22l55 19.8c9.6 3.5 19.6-4.3 19.6-15.3V298.3c0-5.8 2-11.4 5.6-15.7l152.2-179.8c3.6-4.3 5.6-9.9 5.6-15.7 0-12.8-9.6-23.2-21.4-23.2H69.4C57.6 64 48 74.4 48 87.2z"
        },
        {
            iconName: "close-circle",
            iconValue: "M256 48C140.559 48 48 140.559 48 256c0 115.436 92.559 208 208 208 115.435 0 208-92.564 208-208 0-115.441-92.564-208-208-208zm104.002 282.881l-29.12 29.117L256 285.117l-74.881 74.881-29.121-29.117L226.881 256l-74.883-74.881 29.121-29.116L256 226.881l74.881-74.878 29.12 29.116L285.119 256l74.883 74.881z"
        }
    ];

    var indexLocation = d.map(function (e) { return e.iconName; }).indexOf(svgName);

    if (indexLocation != -1) {
        // Icon has been found. Hence retrieve the respective icon value.
        let iconValue = d[indexLocation].iconValue;

        let svgEl = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="s-ion-icon"><path d="' + iconValue + '"></path></svg>';

        let svgElToNode = new DOMParser().parseFromString(svgEl, "text/xml");

        icon_inner_elem.appendChild(svgElToNode.firstChild);
    }
};

var domMutationObserver = (el) => {
    // Select the node that will be observed for mutations
    const targetNodesAll = document.querySelectorAll(el);

    // Options for the observer (which mutations to observe)
    const config = { attributes: true, childList: true, subtree: true };

    // Callback function to execute when mutations are observed
    const callback = function (mutationsList, observer) {
        // Use traditional 'for loops' for IE 11
        for (let mutation of mutationsList) {
            if (mutation.type === 'childList' || mutation.type === 'attributes') {
                if (mutation.target && mutation.target.tagName.toLowerCase()) {
                    if (mutation.target.tagName.toLowerCase() == "ion-icon" && mutation.target.shadowRoot.children.length) {
                        if (mutation.target.shadowRoot.children[0].classList.contains("icon-inner")) {
                            let icon_inner_elem = mutation.target.shadowRoot.children[0];

                            let svgName = mutation.target.getAttribute("name");
                            // Insert SVG into respective ion-icon
                            insertSVG(svgName, icon_inner_elem);
                        }
                    }
                }
            }
        }
    };

    // Create an observer instance linked to the callback function
    const observer = new MutationObserver(callback);

    // Start observing the target node for configured mutations
    targetNodesAll.forEach((targetNode) => {
        observer.observe(targetNode, config);
    });
};

window.addEventListener("load", (evt) => {
    // Observing underlying changes within the <ion-icon> elements to apply any inserted icons accordingly
    domMutationObserver("ion-app");

    // Initializing drop locators here
    initializeDropLocators();
});